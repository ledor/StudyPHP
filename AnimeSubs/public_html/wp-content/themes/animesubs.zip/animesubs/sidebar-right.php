		<div class="rsidebar">
		<ul>
			<?php /* Widgetized sidebar */
			if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar') ) : ?><?php endif; ?>
		</ul>
		</div>
		<div class="clear"></div>
