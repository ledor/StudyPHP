Steps:
1. Create Database
2. Install Wordpress
3. Change Category 1 to News
4. Change setting, reading 20 posts, 10 items
    media thumbnail 135 x 190
              medium size: 300 x 422
              embed 600 x 438
              uploading files images , uncheck Organize
    permalinks %postname%
5. Create Menu


right side bar, 160 x 600

$mysql_host = "mysql5.000webhost.com";
$mysql_database = "a1721076_anime";
$mysql_user = "a1721076_anime";
$mysql_password = "vassword1223";

Keep this login information for your records:
Client ID: 835659
Login email: vledor0723@gmail.com
Password: vassword1223

$mysql_host = "fdb3.runhosting.com";
$mysql_database = "835659_anime";
$mysql_user = "835659_anime";
$mysql_password = "vassword1223";

