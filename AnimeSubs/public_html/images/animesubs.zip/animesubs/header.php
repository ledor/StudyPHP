<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php
	if (is_category() || is_single() ) {
		echo "Download ";
		wp_title( '' ,  true );
		if (is_category () ) {
			echo " Episodes | ";
		} else {
			echo " | ";
		}
		bloginfo( 'name' );
	}
	else {
		wp_title( '|', true, 'right' );
		bloginfo( 'name' );
		$site_description = get_bloginfo( 'description', 'display' );
		if ( $site_description && ( is_home() || is_front_page() ) )
			echo " | $site_description";
	}
?></title>
<meta name="description" content="<?php get_bloginfo( 'description', 'display' ) ?>" />
<meta name="keywords" content="<?php get_bloginfo( 'description', 'display' ) ?>" />
<link rel="shortcut icon" href="favicon.ico">
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript">
<![endif]-->
</script>
<?php
//	wp_head();
?>
</head>
<body>
<div id="page">
	<div id="header">
		<div id="headerimg">
		</div>
		<?php if ( function_exists( 'wp_nav_menu' ) ){
			wp_nav_menu( array('container' => 'false','menu_class' => 'navi', 'link_before' => '<span></span>' ));
		}else{
			primarymenu();
		}?>
		<ul id="top-search">
			<li> 
				<form method="get" id="searchwrap" action="<?php bloginfo('siteurl'); ?>"> 
				<input type="text" value="Search Anime Here"  name="s" id="s"  onblur="if (this.value == '') {this.value = 'Search Anime Here';}"  onfocus="if (this.value == 'Search Anime Here')  {this.value = '';}" />
				<input type="hidden" id="searchsubmit" />
				</form>
			</li>
		</ul>
	</div>
	<div class="topad">
		<div class="ad"></div>
		<div class="clear"></div>
	</div>
	<div id="wrapper">
	<?php get_sidebar ('left'); ?>
		<div id="content">
