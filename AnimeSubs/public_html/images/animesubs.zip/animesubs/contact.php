<?php
	get_header();
?>
			<script type="text/javascript">
			 $(document).ready(function(){
				  $('#contact').ajaxForm(function(data) {
					 if (data==1){
						 $('#success').fadeIn("slow");
						 $('#bademail').fadeOut("slow");
						 $('#badserver').fadeOut("slow");
						 $('#contact').resetForm();
						 }
					 else if (data==2){
							 $('#badserver').fadeIn("slow");
						  }
					 else if (data==3)
						{
						 $('#bademail').fadeIn("slow");
						}
						});
					 });
			</script>
			<div class="post" id="post-<?php the_ID() ?>">
				<div class="entrytext">
					<div class="postdesc">
						<p><h1>Requests, Comments, Concerns, or Complain</h1></p>
						<p>Please be very specific on the subject when you are sending requests.</p>
						<p>Example of using proper subject tag:</p>
						<p>- Anime Request<br />
						- Advertise on Site<br />
						- Annoying Advertisement<br />
						- Inappropriate comments (racists, hate etc&#8230;)</p>
						<p>We will try our best to reply all your emails.</p>
						<p>&nbsp;</p>
						<p><center><br />
						<p><?php echo stripslashes(stripslashes(get_option('boldy_contact_text')))?></p>
						<p id="success" class="successmsg" style="display:none;">Your email has been sent! Thank you!</p>
						<p id="bademail" class="errormsg" style="display:none;">Please enter your name, a message and a valid email address.</p>
						<p id="badserver" class="errormsg" style="display:none;">Your email failed. Try again later.</p>
						<form id="contact" action="<?php bloginfo('template_url'); ?>/sendmail.php" method="post">
							<label for="uname">Your name: *</label>
							<input type="text" id="nameinput" name="uname" value=""/>
							<label for="email">Your email: *</label>
							<input type="text" id="emailinput" name="email" value=""/>
							<label for="subject">Your name: *</label>
							<input type="text" id="subjectinput" name="subject" value=""/>
							<label for="comment">Your message: *</label>
							<textarea cols="20" rows="7" id="commentinput" name="comment"></textarea><br />
							<input type="submit" id="submitinput" name="submit" class="submit" value="SEND MESSAGE"/>
							<input type="hidden" id="receiver" name="receiver" value="<?php echo get_option('boldy_contact_email')?>"/>
						</form>
					</div>
				</div>
			</div>
		</div>
<?php get_sidebar('right'); ?>
<?php get_footer(); ?>