<?php
	get_header();
?>
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<?php $categories = get_the_category(); ?>
			<?php $category = $categories[0]; ?>
			<div class="post" id="post-<?php the_ID() ?>">
				<div class="postdesc">
					<h1><?php the_title(); ?></h1>
					<p><strong>Category: </strong><a href="<?php echo get_category_link( $category->cat_ID ); ?>" title="<?php echo $category->name; ?>" rel="category tag"><?php echo $category->name; ?></a></p>
				</div>
				<div class="postdesc">
					<p>&#9643; <a class="drop-btn" href="javascript:void(0)">Download <?php the_title(); ?></a> with high definition (HD) quality.</p>
						<div class="drop">
						<?php
							$dllink = get_post_custom_values('dllink');
							$ddllink = get_post_custom_values('ddllink');
							if (count($dllink) > 0) {
								$i = 1;
								foreach ( $dllink as $key => $value ) {
									$url = $value;
									$siteTitle = getMetaTitle($url);
						?>
					<p>&#9643; Mirror <?php echo $i; ?> : <a target="_blank" href="<?php echo $url; ?>"><?php echo $siteTitle; ?></a></p>
						<?php
									$i++;
								}
							}
							else {
						?>
					<p>Sorry, we haven't uploaded the video. We will upload it as soon as possible.</p>
						<?php
							}
						?>
				</div>
				</div>
				<div class="postdesc">
					<table border="0" width="600" style="border-collapse: collapse" cellpadding="0" height="60">
						<tr>
							<td width="468" height="60">
								<script type="text/javascript"><!--
								google_ad_client = "pub-3403248656087830";
								/* 468x60, NewAnimeSubs */
								google_ad_slot = "6518938124";
								google_ad_width = 468;
								google_ad_height = 60;
								//-->
								</script>
								<script type="text/javascript"
								src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
								</script>
							</td>
							<td>&nbsp;</td>
							<td width="238"><font color="#FF0000">Video not playing? </font><a href="<?php echo curPageURL(); ?>">Click here</a>! If it doesn't work, try a different version.</td>
						</tr>
					</table>
				</div>
				<?php 
				$content_arr = explode("[tab]",get_the_content());
				$arr_count = count($content_arr);
				$url_arr = explode("/",curPageURL());
				if (empty($url_arr[4])) {
					$active = 0;
				} else {
					$active = $url_arr[4] - 1;
					if($url_arr[4] > $arr_count) {
						$active = $arr_count - 1;
					}
				}
				$tab_string = "";
				for ($i = 0; $i < $arr_count; $i++) {
					if ($i == $active) {
						$tab_string = $tab_string . ' Version ' . ($i + 1) . ' ';
					} else {
						$extra = '/' . ($i + 1);
						$tab_string = $tab_string . ' <a href="' . get_permalink() . (($i == 0) ? '' : $extra) . '">'. 'Version ' . ($i + 1) . '</a>' ;
					}
				}
				?>
				<div class="versiontab"><div class="tabpadding"><p><font color="#FF0000"><?php echo $tab_string; ?></font></p></div></div>
				<div class="postcontent">
				<?php
					
					$content = resizeMarkup($content_arr[$active], array('width'=>600,'height'=>550));
					echo $content;
				?>
				</div>
				<div class="postdesc">
					<?php previous_post_link('<div class="alignleft">%link</div>','&#9668;&nbsp; %title',true); ?>
					<?php next_post_link('<div class="alignright">%link</div>','%title &nbsp;&#9658;',true); ?>
					<div class="clear"></div>
				</div>
			</div>
			<?php comments_template(); ?>
			<?php endwhile; ?>
			<?php else : ?>
				<p>Sorry, but you are looking for something that isn't here.</p>
			<?php endif; ?>
		</div>
<?php get_sidebar('right'); ?>
<?php get_footer(); ?>