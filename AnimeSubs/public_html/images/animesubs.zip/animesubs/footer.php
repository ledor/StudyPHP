	</div>
<div id="footer">
<?php if(get_option('boldy_footer_actions')!="no") {?>
	<div style="width:960px; margin: 0 auto; position:relative;">
	</div>
	<?php }?>
	<div id="footerWidgets">
		<div id="footerWidgetsInner">
			<?php /* Widgetized sidebar */
			if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer') ) : ?><?php endif; ?>
			<div id="copyright">
					<p>Copyright &copy; <?php echo date('Y'); ?><a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"> <?php bloginfo('name'); ?></a> - <?php bloginfo('description'); ?>.</p>
			</div>
		</div>
	</div>
</div>	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){ //hide the all of the element with class msg_body
	 $(".drop").hide();  //toggle the component with class msg_body
	 $(".drop-btn").click(function()
	 {
	 		$(".drop").slideToggle();
		});});
</script>
</body>
</html>
