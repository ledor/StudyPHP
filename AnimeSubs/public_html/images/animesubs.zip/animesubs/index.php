<?php get_header(); ?>
			<h2>News & Updates</h2>
			<div class="postcontent">
				<div class="post">
					<div class="newsupdates">
						<ul>
							<li><b><font size="2">Important - Remember to report broken links, staffs are very active here!</font></b></li>
							<?php
							$recent_posts = wp_get_recent_posts(array('category' => 1, 'numberposts' => 4));
							foreach( $recent_posts as $post ){
							echo '<li><b><font size="2">' . $post["post_content"] .'</font></b></li>  ';
							}
							?>
							</ul>
					</div>
				</div>
			</div>
			<div class="post">
				<div align="left">
					<table border="0" width="600" style="border-collapse: collapse">
						<tr>
							<td width="384">
								<h2>Recent Release</h2>
							</td>
							<td width="210">
								<h2>Recently Added Series</h2>
							</td>
						</tr>
					</table>
				</div>
				<div align="left">
					<table border="0" width="600" style="border-collapse: collapse">
						<tr>
							<td width="384" bgcolor="#313131" valign="top">
								<ul>
								<?php
								$recent_posts = wp_get_recent_posts(array('numberposts' => 25,'category' => -1));
								foreach( $recent_posts as $post ){
									$atype = get_post_custom_values('atype',$post["ID"]);
									if ($atype[0] <> 'Sub') {
										$satype = '<font color="#FF0000">' . $atype[0] . ', </font>';
									} else {
										$satype = $atype[0] . ', ';
									}
									$asize = get_post_custom_values('asize',$post["ID"]);
									if ($asize[0] <> '720') {
										$sasize = '<font color="#FF0000">' . $asize[0] . '</font>';
									} else {
										$sasize = $asize[0];
									}
								echo '<li><a href="' . get_permalink($post["ID"]) . '" title="Watch or Download '.$post["post_title"].'" >' .   $post["post_title"].'</a> <font color="#00CC00">(' . $satype . $sasize . ')</font> </li> ';
								}
								?>
								</ul>
							</td>
							<td width="2" bgcolor="#313131" valign="top">&nbsp;</td>
							<td width="210" bgcolor="#313131" valign="top">
								<ul>
								<?php
								$categories=get_categories(array('exclude' => 1, 'number' => 25, 'orderby' => 'id', 'order' => 'DESC', 'hide_empty' => 0));
								foreach($categories as $category) {
									//if ($category->count > 0) {
									echo '<li><a href="' . get_category_link( $category->term_id ) . '" title="Watch or Download Episodes of '.$category->name.'" >' . $category->name.'</a> </li> ';
									//}
								}
								?>
								</ul>
							</td>
						</tr>
					</table>
				</div>
			</div>	
			<p>&nbsp;</p>
			<h2>Latest Recommended Anime</h2>
			<?php
			$categories=get_categories(array('exclude' => 1,'orderby' => 'id', 'order' => 'DESC', 'hide_empty' => 0));
			$count = 1;
			foreach($categories as $category) {
				if ($count > 20) {
					break;
				}
				list($featured, $recommend, $ongoing, $genre, $director, $studio, $tvnetwork, $description, $plot) = explode("[nxt]", $category->description);
				if ($recommend == "Recommended") {
				$cat_name = substr($category->name, 0, 22);
				echo '
			<div class="entry">
				<ul class="imagelist">
					<div align="center">
						<div class="gallery">
							<div class="picture">
								<a href="' . get_category_link( $category->term_id ) . '" title="Watch or Download Episodes of '. $category->name . '"><img src="/images/' . $category->cat_ID . '-135x190.jpg" witdh="135px"; height="190px"></img></a>
							</div>
							<div class="title"><a href="' . get_category_link( $category->term_id ) . '">' . $cat_name . '</a></div>
							<div class="clear"></div>
						</div>
					</div>
				</ul>
			</div>' ;
					$count += 1;
				}
			}
			?>
		</div>
<?php get_sidebar('right'); ?>
<?php get_footer(); ?>